<?p<?php

class insert_ctrl extends CI_Controller {

function __construct() {
parent::__construct();
$this->load->model('insert_model');

}
function index() {
//Including validation library
$this->load->library('form_validation');

$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

//Validating Name Field
$this->form_validation->set_rules('dname', 'name', 'required|min_length[5]|max_length[15]');

//Validating Email Field
$this->form_validation->set_rules('dcode', 'code','required|min_length[2]' );


$this->form_validation->set_rules('dimage', 'image', 'required|min_length[2]');


//Validating Mobile no. Field
$this->form_validation->set_rules('ddescrip', 'description', 'required|min_length[4]|max_length[15]');

if ($this->form_validation->run() == FALSE) {
$this->load->view('insert_view');
} else {
//Setting values for tabel columns
$data = array(
'name' => $this->input->post('dname'),
'code' => $this->input->post('dcode'),
'image' => $this->input->post('dimage'),
'description' => $this->input->post('ddescrip'),
);
//Transfering data to Model
$this->insert_model->form_insert($data);
$data['message'] = 'Data Inserted Successfully';
//Loading View
$this->load->view('insert_view', $data);
}
}

}

?>