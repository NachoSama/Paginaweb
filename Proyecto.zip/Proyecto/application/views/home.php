<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$base_url = base_url();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Codeigniter Shopping cart</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<link id="callCss" rel="stylesheet" href="<?= $base_url ?>themes/bootshop/bootstrap.min.css" media="screen"/>
<link href="<?= $base_url?>themes/css/base.css" rel="stylesheet" media="screen"/>
<!-- Bootstrap style responsive -->
<link href="<?= $base_url?>themes/css/bootstrap-responsive.min.css" rel="stylesheet"/>
<link href="<?= $base_url?>themes/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Google-code-prettify -->
<link href="<?= $base_url?>themes/js/google-code-prettify/prettify.css" rel="stylesheet"/>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<style type="text/css" id="enject"></style>
</head>
<body>
<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
<div class="span6">
</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<div class="navbar-inner">
<a class="brand" href="index.html"></a>
<a href="<?php echo base_url('home');?>"><span class="btn btn-small btn-success">Lista</span></a>
<div class="pull-right">
<a href="<?php echo base_url('insert_ctrl');?>"><span class="btn btn-small btn-success">Agregar productos</span></a>
<a href="<?php echo base_url('delete_ctrl/show_id');?>"><span class="btn btn-small btn-success">Quitar productos</span></a>

<a href="<?php echo base_url('cart');?>"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> <span class="count"><?= $this->cart->total_items() ?></span> Articulo(s) en tu lista </span> </a>

</div>
</div>
</div>
</div>
</div>
<div id="mainBody">
<div class="container">
<div class="row">
<div class="span12">
<!-- <h4>Latest Products </h4> -->
<ul class="thumbnails">
<?php
if(!empty($cart_data)){
foreach($cart_data as $row){
?>
<li class="span3">
<div class="thumbnail">
<a href="product_details.html"><img src="<?= $row->image ?>" alt=""/></a>
<div class="caption">
<h5><?= $row->name ?></h5>
<p>
<?= $row->description ?>
</p>
<h4 style="text-align:center">
<a class="btn" href="javascript:void(0)" onclick="addtocart(<?= $row->id ?>)">Agregar a <i class="icon-shopping-cart"></i></a> <!-- <a class="btn btn-primary" href="#">Rs- <?= $row->price ?></a></h4> -->
</div>
</div>
</li>
<?php
}
} ?>
</ul>
</div>
</div>
</div>
</div>
<script>
function addtocart(id){
if(id != ""){
$.ajax({
url:'<?php echo base_url(); ?>home/addtocart',
type:'POST',
dataType:'json',
data:{
'id' : id
},
success: function(data) {
$('.count').html(data.count);
//location.reload();
}
});
} else {
return false;
}
return false;
}
</script>
</body>
</html>