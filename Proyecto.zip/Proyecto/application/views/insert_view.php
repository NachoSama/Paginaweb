<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$base_url = base_url();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Codeigniter Shopping cart</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<link id="callCss" rel="stylesheet" href="<?= $base_url ?>themes/bootshop/bootstrap.min.css" media="screen"/>
<link href="<?= $base_url?>themes/css/base.css" rel="stylesheet" media="screen"/>
<!-- Bootstrap style responsive -->
<link href="<?= $base_url?>themes/css/bootstrap-responsive.min.css" rel="stylesheet"/>
<link href="<?= $base_url?>themes/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Google-code-prettify -->
<link href="<?= $base_url?>themes/js/google-code-prettify/prettify.css" rel="stylesheet"/>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<style type="text/css" id="enject"></style>
</head>
<body>
<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
<div class="span6">
</div>
</div>
<div id="container">
</small>]<a href="<?php echo base_url('home');?>" class="btn btn-short pull-right"><i class="icon-arrow-left"></i> Volver Atras </a></h3>
<?php echo form_open('insert_ctrl'); ?>
<h1>Agregar productos</h1><hr/>
<?php if (isset($message)) { ?>
<CENTER><h3 style="color:green;">producto insertado correctamente</h3></CENTER><br>
<?php } ?>
<?php echo form_label('Name :'); ?> <?php echo form_error('dname'); ?><br />
<?php echo form_input(array('id' => 'dname', 'name' => 'dname')); ?><br />

<?php echo form_label('Code :'); ?> <?php echo form_error('dcode'); ?><br />
<?php echo form_input(array('id' => 'dcode', 'name' => 'dcode')); ?><br />

<?php echo form_label('image(url) :'); ?> <?php echo form_error('dimage'); ?><br />
<?php echo form_input(array('id' => 'dimage', 'name' => 'dimage')); ?><br />

<?php echo form_label('Descpription'); ?> <?php echo form_error('ddescrip'); ?><br />
<?php echo form_input(array('id' => 'ddescrip', 'name' => 'ddescrip')); ?><br />

<?php echo form_submit(array('id' => 'submit', 'value' => 'Submit')); ?>
<?php echo form_close(); ?><br/>
<div id="fugo">

</div>
</div>
</body>
</html>