<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$base_url = base_url();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Codeigniter Shopping cart</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<link id="callCss" rel="stylesheet" href="<?= $base_url ?>themes/bootshop/bootstrap.min.css" media="screen"/>
<link href="<?= $base_url?>themes/css/base.css" rel="stylesheet" media="screen"/>
<!-- Bootstrap style responsive -->
<link href="<?= $base_url?>themes/css/bootstrap-responsive.min.css" rel="stylesheet"/>
<link href="<?= $base_url?>themes/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Google-code-prettify -->
<link href="<?= $base_url?>themes/js/google-code-prettify/prettify.css" rel="stylesheet"/>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<style type="text/css" id="enject"></style>
</head>
<body>
<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
<div class="span6">

</div>
</div>
</small>]<a href="<?php echo base_url('home');?>" class="btn btn-short pull-right"><i class="icon-arrow-left"></i> Volver Atras </a>
        <div id="container">
            <div id="wrapper">
                <h1>Eliminar objetos</h1><hr/> 
                <div id="menu">
                    <p>Click On Menu</p>
					 <!--------Displaying Fetched Names from database in Links----------> 
                    <ol>
                        <?php foreach ($tblproduct as $product): ?>
                            <li><a href="<?php echo base_url() . "index.php/delete_ctrl/show_id/" . $product->id; ?>"><?php echo $product->name; ?></a></li>
                        <?php endforeach; ?>
                    </ol>
                </div>
                <div id="detail">
                   
				   <!--------Displaying Fetched Details from database ---------->  
                    <?php foreach ($single_product as $tblproduct): ?>
                        <p>Product Detail</p>|
                        <?php echo $product->name; ?><br/>
                        <?php echo $product->code; ?><br/>
                        <!---- <?php echo $product->image; ?><br/>--->
                        <?php echo $product->description; ?><br/>
					
					<!--------Delete button ----------> 	
                    <a href="<?php echo base_url() . "index.php/delete_ctrl/delete_id/" . $product->id; ?>"><button>Delete</button></a>
                    <?php endforeach; ?>


                </div> 
            </div> 

        </div>
    </body>
</html>